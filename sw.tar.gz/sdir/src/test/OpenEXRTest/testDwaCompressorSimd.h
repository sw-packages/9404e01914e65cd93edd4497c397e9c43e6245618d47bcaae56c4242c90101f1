//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) DreamWorks Animation LLC and Contributors of the OpenEXR Project
//

#ifndef TESTDWACOMPRESSORSIMD_H_
#define TESTDWACOMPRESSORSIMD_H_

#include <string>
void testDwaCompressorSimd(const std::string&);

#endif /* TESTDWACOMPRESSORSIMD_H_ */

